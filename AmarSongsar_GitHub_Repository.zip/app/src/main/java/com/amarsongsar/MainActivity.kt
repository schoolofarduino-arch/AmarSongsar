package com.amarsongsar

import android.app.Activity
import android.os.Bundle
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Txn(
    val id: Long, val type: String, val amount: Long, val category: String,
    val note: String, val date: String, val account: String, val member: String
)

class LedgerDb(ctx: Context) : SQLiteOpenHelper(ctx, "amar_songsar.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL,
            amount INTEGER NOT NULL CHECK(amount > 0), category TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '', date TEXT NOT NULL,
            account TEXT NOT NULL DEFAULT 'নগদ', member TEXT NOT NULL DEFAULT 'আমি'
        )""")
        db.execSQL("CREATE INDEX idx_txn_date ON transactions(date)")
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(type: String, amount: Long, category: String, note: String, date: String, account: String, member: String) {
        require(amount > 0)
        val v = ContentValues().apply {
            put("type", type); put("amount", amount); put("category", category)
            put("note", note); put("date", date); put("account", account); put("member", member)
        }
        writableDatabase.insertOrThrow("transactions", null, v)
    }
    fun all(): List<Txn> {
        val out = mutableListOf<Txn>()
        readableDatabase.rawQuery("SELECT id,type,amount,category,note,date,account,member FROM transactions ORDER BY date DESC,id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Txn(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getString(7)))
        }
        return out
    }
    fun totals(): Pair<Long, Long> {
        var income = 0L; var expense = 0L
        readableDatabase.rawQuery("SELECT type, SUM(amount) FROM transactions GROUP BY type", null).use { c ->
            while (c.moveToNext()) if (c.getString(0) == "আয়") income = c.getLong(1) else expense = c.getLong(1)
        }
        return income to expense
    }
    fun setSetting(key: String, value: String) {
        val cv = ContentValues().apply { put("key", key); put("value", value) }
        writableDatabase.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun getSetting(key: String): String? {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }
    fun exportJson(): String {
        val root = JSONObject().put("app", "AmarSongsar").put("version", 1).put("exportedAt", System.currentTimeMillis())
        val arr = JSONArray()
        all().forEach { t -> arr.put(JSONObject().put("type",t.type).put("amount",t.amount).put("category",t.category).put("note",t.note).put("date",t.date).put("account",t.account).put("member",t.member)) }
        root.put("transactions", arr)
        return root.toString(2)
    }
    fun importJson(json: String): Int {
        val root = JSONObject(json); val arr = root.getJSONArray("transactions"); var n = 0
        writableDatabase.beginTransaction()
        try {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val type = o.getString("type"); val amount = o.getLong("amount")
                if ((type != "আয়" && type != "ব্যয়") || amount <= 0) continue
                add(type, amount, o.optString("category","অন্যান্য"), o.optString("note",""),
                    o.optString("date",today()), o.optString("account","নগদ"), o.optString("member","আমি"))
                n++
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
        return n
    }
}

fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
fun hash(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
fun money(n: Long) = "৳ " + String.format(Locale.US, "%,d", n)

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var root: LinearLayout
    private val pickExport = 101
    private val pickImport = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LedgerDb(this)
        if (db.getSetting("pin_hash") == null) setupPin() else lockScreen()
    }
    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 22, 24, 16); setBackgroundColor(0xFFF7F8FA.toInt()) }
        val scroll = ScrollView(this); scroll.addView(root)
        setContentView(scroll)
        val h = TextView(this).apply { text = title; textSize = 26f; setTextColor(0xFF123D35.toInt()); typeface = Typeface.DEFAULT_BOLD; setPadding(0,0,0,18) }
        root.addView(h)
    }
    private fun label(s: String, size: Float = 16f) { root.addView(TextView(this).apply { text=s; textSize=size; setTextColor(0xFF202124.toInt()); setPadding(0,8,0,8) }) }
    private fun field(hint: String): EditText = EditText(this).apply { this.hint=hint; textSize=16f; singleLine=true; setPadding(12,8,12,8); backgroundTintList=android.content.res.ColorStateList.valueOf(0xFF9AA5A4.toInt()); root.addView(this) }
    private fun btn(text: String, action: () -> Unit) { root.addView(Button(this).apply { this.text=text; isAllCaps=false; setOnClickListener { action() } }) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun setupPin() {
        base("আমার সংসার — সেটআপ")
        label("আপনার ব্যক্তিগত PIN তৈরি করুন। অন্তত ৪টি অঙ্ক দিন।")
        val p1 = field("নতুন PIN (৪–১২ অঙ্ক)"); p1.inputType = 2
        val p2 = field("PIN আবার লিখুন"); p2.inputType = 2
        btn("PIN সংরক্ষণ করুন") {
            val a=p1.text.toString(); val b=p2.text.toString()
            if (a.length < 4 || a.length > 12 || a.any { !it.isDigit() } || a != b) toast("সঠিকভাবে একই ৪–১২ অঙ্কের PIN দিন")
            else { db.setSetting("pin_hash", hash(a)); showHome() }
        }
        label("PIN ভুলে গেলে এই সংস্করণে অ্যাপের ডেটা মুছে পুনরায় সেটআপ করতে হবে। তাই ব্যাকআপ রাখুন।", 13f)
    }
    private fun lockScreen() {
        base("আমার সংসার")
        label("PIN দিয়ে আনলক করুন")
        val pin = field("PIN"); pin.inputType=2
        btn("আনলক") {
            if (hash(pin.text.toString()) == db.getSetting("pin_hash")) showHome()
            else toast("PIN সঠিক নয়")
        }
        val can = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
        if (can == BiometricManager.BIOMETRIC_SUCCESS) btn("ফিঙ্গারপ্রিন্ট / ফোনের লক ব্যবহার করুন") { biometricUnlock() }
    }
    private fun biometricUnlock() {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object: BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { showHome() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { toast("আনলক করা যায়নি: $errString") }
        })
        val info = BiometricPrompt.PromptInfo.Builder().setTitle("আমার সংসার আনলক").setSubtitle("ফিঙ্গারপ্রিন্ট বা ডিভাইসের নিরাপত্তা ব্যবহার করুন")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL).build()
        prompt.authenticate(info)
    }
    private fun showHome() {
        base("আমার সংসার")
        val (income, expense)=db.totals()
        label("সব লেনদেনের মোট আয়: ${money(income)}")
        label("সব লেনদেনের মোট ব্যয়: ${money(expense)}")
        label("নিট পার্থক্য: ${money(income-expense)}", 20f)
        btn("+ আয় যোগ করুন") { addTxn("আয়") }
        btn("+ ব্যয় যোগ করুন") { addTxn("ব্যয়") }
        btn("লেনদেনের তালিকা") { listTxns() }
        btn("JSON ব্যাকআপ তৈরি করুন") { exportBackup() }
        btn("JSON ব্যাকআপ থেকে পুনরুদ্ধার") { importBackup() }
        btn("অ্যাপ লক করুন") { lockScreen() }
        label("অফলাইন অ্যাপ • ডেটা এই ফোনে থাকে • অন্য ফোনে নিতে ব্যাকআপ ফাইল স্থানান্তর করুন", 13f)
    }
    private fun addTxn(type: String) {
        base("$type যোগ করুন")
        val amount=field("পরিমাণ (টাকা)"); amount.inputType=8194
        val category=field("খাত (যেমন বাজার, বেতন, চিকিৎসা)")
        val note=field("বিবরণ (ঐচ্ছিক)")
        val date=field("তারিখ YYYY-MM-DD"); date.setText(today())
        val account=field("অ্যাকাউন্ট (নগদ/ব্যাংক/মোবাইল ব্যাংকিং)"); account.setText("নগদ")
        val member=field("পরিবারের সদস্যের নাম"); member.setText("আমি")
        btn("সংরক্ষণ করুন") {
            val a=amount.text.toString().trim().toLongOrNull()
            if (a == null || a <= 0) { toast("শূন্যের বেশি সঠিক পরিমাণ দিন"); return@btn }
            if (category.text.toString().trim().isEmpty()) { toast("খাত লিখুন"); return@btn }
            val d=date.text.toString().trim()
            if (!d.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { toast("তারিখ YYYY-MM-DD ফরম্যাটে দিন"); return@btn }
            try {
                db.add(type,a,category.text.toString().trim(),note.text.toString().trim(),d,
                    account.text.toString().trim().ifEmpty{"নগদ"}, member.text.toString().trim().ifEmpty{"আমি"})
                toast("লেনদেন সংরক্ষণ হয়েছে"); showHome()
            } catch (e: Exception) { toast("সংরক্ষণ করা যায়নি: ${e.message}") }
        }
        btn("ফিরে যান") { showHome() }
    }
    private fun listTxns() {
        base("লেনদেনের তালিকা")
        val items=db.all()
        if (items.isEmpty()) label("এখনও কোনো লেনদেন যোগ করা হয়নি।")
        items.forEach { t ->
            val sign=if(t.type=="আয়") "+" else "−"
            label("$sign ${money(t.amount)} • ${t.category}\n${t.date} | ${t.member} | ${t.account}\n${t.note}", 15f)
            root.addView(View(this).apply { setBackgroundColor(0xFFDDE3E2.toInt()); layoutParams=LinearLayout.LayoutParams(-1,1) })
        }
        btn("ফিরে যান") { showHome() }
    }
    private fun exportBackup() {
        val intent=android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE); type="application/json"
            putExtra(android.content.Intent.EXTRA_TITLE, "amar_songsar_backup_${today()}.json")
        }
        startActivityForResult(intent,pickExport)
    }
    private fun importBackup() {
        val intent=android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE); type="application/json"
        }
        startActivityForResult(intent,pickImport)
    }
    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode != RESULT_OK || data?.data == null) return
        val uri=data.data!!
        try {
            if(requestCode==pickExport) {
                contentResolver.openOutputStream(uri)?.use { it.write(db.exportJson().toByteArray(Charsets.UTF_8)) }
                toast("ব্যাকআপ ফাইল তৈরি হয়েছে")
            } else if(requestCode==pickImport) {
                val json=contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val count=db.importJson(json)
                toast("$countটি লেনদেন আমদানি হয়েছে")
                showHome()
            }
        } catch(e: Exception) { toast("ব্যাকআপ কাজটি সম্পন্ন হয়নি: ${e.message}") }
    }
}
