# GitHub-এ আপলোড করার সহজ নিয়ম

1. GitHub.com-এ লগইন করুন।
2. `New repository` চাপুন।
3. Repository name দিন: `amar-songsar-android`।
4. `Public` বা `Private` বেছে `Create repository` চাপুন।
5. `Add file` → `Upload files` নির্বাচন করুন।
6. এই ZIP Extract করে ভেতরের সব ফাইল/ফোল্ডার upload করুন। ZIP ফাইলটিকে সরাসরি repository-তে upload করলেই source code স্বয়ংক্রিয়ভাবে খুলে যাবে না।
7. Commit changes করুন।
8. `Actions` ট্যাবে গিয়ে Android build workflow-এর ফল দেখুন। সফল হলে run-এর Artifacts অংশ থেকে APK নামিয়ে নিতে পারবেন।

**গুরুত্বপূর্ণ:** এই starter সংস্করণে wrapper script নেই; GitHub Actions workflow runner-এ Gradle 8.9 ব্যবহার করে build করার চেষ্টা করবে। Android Studio বা GitHub Actions build failure দেখালে সেই error অনুযায়ী project configuration সংশোধন করতে হবে।
