# আমার সংসার (Amar Songsar)

একটি ব্যক্তিগত হিসাব রাখার Android অ্যাপ — অফলাইন-প্রথম (offline-first) Kotlin + SQLite starter project।

## বর্তমান ফিচার

- আয় ও ব্যয় যোগ করা
- লেনদেনের তারিখ, খাত, নোট, অ্যাকাউন্ট ও সদস্য/লেবেল সংরক্ষণ
- মোট আয়, মোট ব্যয় ও নিট পার্থক্য
- লেনদেনের তালিকা
- PIN সেটআপ ও PIN দিয়ে আনলক
- সমর্থিত Android ডিভাইসে BiometricPrompt / device credential
- JSON ব্যাকআপ তৈরি ও পুনরুদ্ধার
- অ্যাপের হিসাবের জন্য ইন্টারনেট অনুমতি প্রয়োজন নেই

## প্রযুক্তি

- Kotlin
- Android SDK 35
- Minimum SDK 26 (Android 8.0)
- SQLite (`SQLiteOpenHelper`)
- AndroidX Biometric

## GitHub-এ ব্যবহার

1. GitHub-এ নতুন repository তৈরি করুন, যেমন `amar-songsar-android`।
2. এই ZIP ফাইল Extract করুন।
3. Extract করা ফাইল ও ফোল্ডারগুলো repository-র root-এ upload করুন; `app`, `.github`, `settings.gradle.kts`, `build.gradle.kts` ইত্যাদি root-এ থাকবে।
4. GitHub Actions ট্যাব থেকে build workflow চালু আছে কি না দেখুন।
5. `Actions` → `Android build` → সর্বশেষ সফল run → `Artifacts` থেকে `amar-songsar-debug-apk` ডাউনলোড করুন।

## Android Studio-তে চালানো

1. Repository clone বা ZIP download করে extract করুন।
2. Android Studio-তে project root folder খুলুন।
3. JDK 17 এবং Android SDK Platform 35 ইনস্টল থাকতে হবে।
4. Gradle sync করুন, তারপর `gradle assembleDebug` বা Android Studio-এর **Build > Build APK(s)** ব্যবহার করুন।

## ডেটাবেস কাঠামো

`transactions`
- `id`: লেনদেনের অনন্য আইডি
- `type`: `আয়` অথবা `ব্যয়`
- `amount`: পূর্ণ টাকা (positive integer)
- `category`: খাত
- `note`: বিবরণ
- `date`: `YYYY-MM-DD`
- `account`: নগদ/ব্যাংক/মোবাইল ব্যাংকিং ইত্যাদি
- `member`: ডিফল্টভাবে `আমি`

`settings`
- `key`
- `value`

## গুরুত্বপূর্ণ সীমাবদ্ধতা — এখনো প্রোডাকশন-রেডি নয়

এটি একটি starter MVP, পূর্ণাঙ্গ ব্যক্তিগত ফিন্যান্স অ্যাপ নয়। বাস্তব সংবেদনশীল হিসাব রাখার আগে নিচের বিষয়গুলো যোগ/পরীক্ষা করতে হবে:

- ডেটাবেস ও ব্যাকআপ এনক্রিপশন
- ব্যাকআপ আমদানির সময় duplicate detection এবং schema validation
- সম্পূর্ণ ক্যালেন্ডার-তারিখ যাচাই
- লেনদেন edit/delete ও ভুল এন্ট্রি সংশোধন
- অ্যাকাউন্টভিত্তিক ব্যালেন্স ও সঠিক transfer flow
- মাসিক/বার্ষিক রিপোর্ট, বাজেট, ঋণ-পাওনা, সম্পদ ও সঞ্চয় মডিউল
- unit/instrumentation tests এবং বাস্তব ডিভাইস পরীক্ষা
- PIN reset/recovery flow

**ব্যাকআপ:** এই সংস্করণে JSON ফাইল plaintext; সেটিতে আর্থিক তথ্য থাকতে পারে। নিরাপদ জায়গায় রাখুন এবং GitHub-এ ব্যক্তিগত ব্যাকআপ আপলোড করবেন না।

## হিসাবের নিয়ম

- মোট আয় = সব `আয়` লেনদেনের যোগফল
- মোট ব্যয় = সব `ব্যয়` লেনদেনের যোগফল
- নিট পার্থক্য = মোট আয় − মোট ব্যয়

টাকা এক অ্যাকাউন্ট থেকে অন্য অ্যাকাউন্টে সরানোকে আয় বা ব্যয় হিসেবে যোগ করা উচিত নয়; ভবিষ্যৎ সংস্করণে আলাদা transfer transaction যোগ করতে হবে।

## লাইসেন্স

MIT License — `LICENSE` ফাইল দেখুন।
